import type { RecentBattle } from "../../types";
import { useNavigate } from "react-router-dom";

const BATTLES: RecentBattle[] = [
  {
    opponent: "algo_beast",
    result: "won",
    opponentRating: 2100,
    ratingDelta: +18,
    problemId: "1923C",
    difficulty: 1800,
    duration: "14:32",
  },
  {
    opponent: "cp_grinder",
    result: "lost",
    opponentRating: 1650,
    ratingDelta: -12,
    problemId: "1850G",
    difficulty: 1600,
    duration: "28:07",
  },
  {
    opponent: "debug_lord",
    result: "won",
    opponentRating: 2350,
    ratingDelta: +22,
    problemId: "1900D",
    difficulty: 2000,
    duration: "31:15",
  },
];

function getDifficultyStyle(rating: number): {
  color: string;
  bg: string;
  border: string;
} {
  if (rating >= 2000)
    return {
      color: "#c084fc",
      bg: "rgba(192,132,252,0.1)",
      border: "rgba(192,132,252,0.25)",
    };
  if (rating >= 1800)
    return {
      color: "#60a5fa",
      bg: "rgba(96,165,250,0.1)",
      border: "rgba(96,165,250,0.25)",
    };
  return {
    color: "#4ade80",
    bg: "rgba(74,222,128,0.1)",
    border: "rgba(74,222,128,0.25)",
  };
}

export default function RecentBattles() {
  const navigate = useNavigate();

  return (
    <section className="px-10 py-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-[18px] font-bold tracking-tight text-white">
          Recent battles
        </h2>
        <button
          className="text-[13px] font-semibold text-white/30 hover:text-accent transition-colors"
          onClick={() =>
            navigate("/profile", { state: { scrollToBottom: true } })
          }
        >
          View all →
        </button>
      </div>

      <div className="flex flex-col gap-1.5">
        {BATTLES.map((battle, index) => {
          const diff = getDifficultyStyle(battle.difficulty);
          const won = battle.result === "won";

          return (
            <div
              key={index}
              className="flex items-center gap-4 px-4 py-3.5 bg-card border border-border rounded-xl hover:border-border-bright hover:bg-elevated transition-colors"
            >
              {/* Win/Loss indicator */}
              <div
                className="flex items-center gap-1.5 text-[13px] font-bold font-mono w-8 flex-shrink-0"
                style={{ color: won ? "#4ade80" : "#f87171" }}
              >
                <span
                  className="w-2 h-2 rounded-full flex-shrink-0"
                  style={{ background: won ? "#4ade80" : "#f87171" }}
                />
                {won ? "W" : "L"}
              </div>

              {/* Opponent info */}
              <div className="flex-1">
                <p className="text-[14px] font-semibold text-white">
                  {battle.opponent}
                </p>
                <p className="text-[12px] font-mono text-white/30">
                  {battle.problemId}
                </p>
              </div>

              {/* Difficulty badge */}
              <span
                className="text-[11px] font-bold font-mono px-2.5 py-1 rounded-full border flex-shrink-0"
                style={{
                  color: diff.color,
                  background: diff.bg,
                  borderColor: diff.border,
                }}
              >
                {battle.difficulty}
              </span>

              {/* Duration */}
              <span className="text-[12px] font-mono text-white/30 flex-shrink-0">
                {battle.duration}
              </span>

              {/* Rating delta */}
              <span
                className="text-[14px] font-bold font-mono w-11 text-right flex-shrink-0"
                style={{ color: won ? "#4ade80" : "#f87171" }}
              >
                {battle.ratingDelta > 0 ? "+" : ""}
                {battle.ratingDelta}
              </span>
            </div>
          );
        })}
      </div>
    </section>
  );
}
