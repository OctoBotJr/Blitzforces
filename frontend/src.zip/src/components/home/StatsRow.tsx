interface StatItem {
  label: string;
  value: string;
  sub: string;
  color: string;
  icon: React.ReactNode;
}

const STATS: StatItem[] = [
  {
    label: "Rating",
    value: "1847",
    sub: "+24 this week",
    color: "#7c6af7",
    icon: (
      <svg
        width="18"
        height="18"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      >
        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
      </svg>
    ),
  },
  {
    label: "Win rate",
    value: "63%",
    sub: "38 / 60 games",
    color: "#4ade80",
    icon: (
      <svg
        width="18"
        height="18"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      >
        <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6" />
        <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18" />
        <path d="M4 22h16" />
        <path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22" />
        <path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22" />
        <path d="M18 2H6v7a6 6 0 0 0 12 0V2z" />
      </svg>
    ),
  },
  {
    label: "Best streak",
    value: "7",
    sub: "Current: 3",
    color: "#fbbf24",
    icon: (
      <svg
        width="18"
        height="18"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      >
        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
      </svg>
    ),
  },
  {
    label: "Avg solve",
    value: "19m",
    sub: "personal best",
    color: "#60a5fa",
    icon: (
      <svg
        width="18"
        height="18"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      >
        <circle cx="12" cy="12" r="10" />
        <polyline points="12 6 12 12 16 14" />
      </svg>
    ),
  },
];

export default function StatsRow() {
  return (
    <section className="border-b border-border bg-surface">
      <div className="max-w-[1200px] mx-auto px-10 py-6">
        <div className="grid grid-cols-4 gap-4">
          {STATS.map((stat) => (
            <div
              key={stat.label}
              className="relative flex flex-col gap-3 px-6 py-5 rounded-2xl bg-card border border-border hover:border-border-bright transition-colors overflow-hidden group"
            >
              {/* Top accent line */}
              <div
                className="absolute top-0 left-0 right-0 h-[2px] rounded-t-2xl opacity-60 group-hover:opacity-100 transition-opacity"
                style={{ background: stat.color }}
              />

              {/* Label + icon */}
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-[1.2px] text-white/30">
                  {stat.label}
                </span>
                <span
                  className="p-1.5 rounded-lg"
                  style={{ color: stat.color, background: stat.color + "18" }}
                >
                  {stat.icon}
                </span>
              </div>

              {/* Value */}
              <span
                className="text-[32px] font-extrabold font-mono leading-none tracking-tight"
                style={{ color: stat.color }}
              >
                {stat.value}
              </span>

              {/* Sub */}
              <span className="text-[12px] text-white/40">{stat.sub}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
