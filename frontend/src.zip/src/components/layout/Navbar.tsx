import { useTheme } from "../../context/ThemeContext";
import { useNavigate } from "react-router-dom";

interface NavbarProps {
  centerLabel?: string;
}

// Codeforces-style icon (3 vertical bars)
function CFIcon() {
  return (
    <div className="flex items-end gap-[2px]">
      <span className="w-[3px] h-[10px] bg-current opacity-70 rounded-sm" />
      <span className="w-[3px] h-[14px] bg-current opacity-85 rounded-sm" />
      <span className="w-[3px] h-[18px] bg-current rounded-sm" />
    </div>
  );
}

export default function Navbar({ centerLabel }: NavbarProps) {
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();

  return (
    <nav className="sticky top-0 z-50 flex items-center justify-between h-[60px] px-6 bg-surface border-b border-border">
      
      {/* Logo ONLY (left side cleaned) */}
      <div className="flex items-center gap-5">
        <div className="flex items-center gap-2 font-syne text-[18px] font-extrabold tracking-tight">
          <span></span>
          <button onClick={() => navigate("/")}>
            Blitz<span className="text-accent">Forces</span>
          </button>
        </div>
      </div>

      {/* Center label */}
      {centerLabel && (
        <span className="text-[11px] font-bold tracking-[2px] uppercase text-white/40">
          {centerLabel}
        </span>
      )}

      {/* Right side */}
      <div className="flex items-center gap-2">

        {/* Problems (NEW - with CF style icon) */}
        {!centerLabel && (
          <button
            onClick={() => navigate("/problems")}
            className="flex items-center gap-2 px-2.5 py-2 rounded-lg text-white/50 text-[13px] font-medium hover:text-white hover:bg-elevated transition-colors"
          >
            <CFIcon />
            Problems
          </button>
        )}

        {/* Rankings */}
        {!centerLabel && (
          <button
            onClick={() => navigate("/rankings")}
            className="flex items-center gap-1.5 px-2.5 py-2 rounded-lg text-white/50 text-[13px] font-medium hover:text-white hover:bg-elevated transition-colors"
          >
            {/* Trophy */}
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6" />
              <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18" />
              <path d="M4 22h16" />
              <path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22" />
              <path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22" />
              <path d="M18 2H6v7a6 6 0 0 0 12 0V2z" />
            </svg>
            Rankings
          </button>
        )}

        {/* Friends */}
        {!centerLabel && (
          <button
            onClick={() => navigate("/friends")}
            className="flex items-center gap-1.5 px-2.5 py-2 rounded-lg text-white/50 text-[13px] font-medium hover:text-white hover:bg-elevated transition-colors"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
            Friends
          </button>
        )}

        {/* Notifications */}
        {!centerLabel && (
          <button className="relative p-2 rounded-lg text-white/50 hover:text-white hover:bg-elevated transition-colors" 
            onClick={()=>navigate("/notifications")}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
              <path d="M13.73 21a2 2 0 0 1-3.46 0" />
            </svg>
            <span className="absolute top-1 right-1 w-4 h-4 bg-accent text-white text-[9px] font-bold font-mono rounded-full flex items-center justify-center">
              3
            </span>
          </button>
        )}

        {/* Theme toggle (UNCHANGED - still commented) */}
        {/* <button
          onClick={toggle}
          className="w-9 h-9 flex items-center justify-center rounded-lg text-white/50 hover:text-warn hover:bg-elevated transition-colors"
          title="Toggle theme"
        >
          {theme === "dark" ? <SunIcon /> : <MoonIcon />}
        </button> */}

        {/* Profile */}
        <button
          onClick={() => navigate("/profile")}
          className="flex items-center gap-2 pl-1.5 pr-3 py-1.5 bg-elevated border border-border rounded-full cursor-pointer hover:border-accent transition-colors"
        >
          <div className="relative w-[30px] h-[30px] rounded-full bg-accent-dim flex items-center justify-center text-[10px] font-bold text-white">
            TK
          </div>
          <div className="flex flex-col gap-0.5">
            <span className="text-[13px] font-semibold">tourist_kid</span>
            <span className="text-[11px] font-mono text-accent">1847</span>
          </div>
        </button>
      </div>
    </nav>
  );
}
