import { useState } from "react";
import type { LeaderboardEntry, Friend } from "../../types";
import { getRatingColor } from "../../utils/rating";

const LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, handle: "tourist",     rating: 3979, delta: +12, flag: "🇧🇾", initials: "TO" },
  { rank: 2, handle: "Um_nik",      rating: 3740, delta: +5,  flag: "🇷🇺", initials: "UN" },
  { rank: 3, handle: "jiangly",     rating: 3700, delta: -3,  flag: "🇨🇳", initials: "JI" },
  { rank: 4, handle: "Petr",        rating: 3650, delta: +8,  flag: "🇷🇺", initials: "PE" },
  { rank: 5, handle: "ksun48",      rating: 3610, delta: +2,  flag: "🇺🇸", initials: "KS" },
  { rank: 6, handle: "tourist_kid", rating: 1847, delta: +24, flag: "🇮🇳", initials: "TK", isMe: true },
];

const FRIENDS: Friend[] = [
  { handle: "code_ninja",  rating: 1920, initials: "CN", online: true,  lastSeen: "In battle" },
  { handle: "algo_beast",  rating: 2100, initials: "AB", online: true,  lastSeen: "Browsing" },
  { handle: "cp_grinder",  rating: 1650, initials: "CG", online: false, lastSeen: "2h ago" },
  { handle: "debug_lord",  rating: 2350, initials: "DL", online: false, lastSeen: "1d ago" },
];

const RANK_MEDALS = ["🥇", "🥈", "🥉"];

type Tab = "leaderboard" | "friends";

export default function Sidebar() {
  const [tab, setTab] = useState<Tab>("leaderboard");

  return (
    <aside className="w-[280px] flex-shrink-0 bg-surface border-r border-border flex flex-col h-[calc(100vh-60px)] sticky top-[60px]">

      {/* Tabs */}
      <div className="flex border-b border-border">
        {(["leaderboard", "friends"] as Tab[]).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 flex items-center justify-center gap-1.5 py-3 text-[13px] font-semibold border-b-2 transition-colors ${
              tab === t
                ? "text-accent border-accent"
                : "text-white/30 border-transparent hover:text-white/60"
            }`}
          >
            {t === "leaderboard" ? (
              <>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
                </svg>
                Rankings
              </>
            ) : (
              <>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
                Friends
              </>
            )}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-2 flex flex-col gap-0.5">

        {tab === "leaderboard" && (
          <>
            <p className="text-[11px] font-bold uppercase tracking-widest text-white/25 px-2 py-2">
              App leaderboard
            </p>

            {LEADERBOARD.map((entry) => (
              <div
                key={entry.rank}
                className={`flex items-center gap-2 px-2 py-2 rounded-lg transition-colors ${
                  entry.isMe
                    ? "bg-accent/10 border border-accent/20"
                    : "hover:bg-elevated"
                }`}
              >
                {/* Rank */}
                <span className="w-7 text-center text-[12px] font-mono text-white/30 flex-shrink-0">
                  {entry.rank <= 3 ? RANK_MEDALS[entry.rank - 1] : `#${entry.rank}`}
                </span>

                {/* Flag */}
                <span className="text-[14px] flex-shrink-0">{entry.flag}</span>

                {/* Handle */}
                <span className="flex-1 text-[13px] font-semibold text-white truncate flex items-center gap-1.5">
                  {entry.handle}
                  {entry.isMe && (
                    <span className="badge-you">you</span>
                  )}
                </span>

                {/* Rating + delta */}
                <div className="flex flex-col items-end gap-0.5">
                  <span
                    className="text-[13px] font-bold font-mono"
                    style={{ color: getRatingColor(entry.rating) }}
                  >
                    {entry.rating}
                  </span>
                  <span
                    className="text-[10px] font-mono"
                    style={{ color: entry.delta > 0 ? "#4ade80" : "#f87171" }}
                  >
                    {entry.delta > 0 ? "+" : ""}
                    {entry.delta}
                  </span>
                </div>
              </div>
            ))}

            <button className="mt-2 w-full py-2.5 text-[12px] font-semibold text-white/25 border border-dashed border-border rounded-lg hover:text-accent hover:border-accent transition-colors">
              View full leaderboard →
            </button>
          </>
        )}

        {tab === "friends" && (
          <>
            <p className="text-[11px] font-bold uppercase tracking-widest text-white/25 px-2 py-2">
              {FRIENDS.filter((f) => f.online).length} online
            </p>

            {FRIENDS.map((friend) => (
              <div key={friend.handle} className="flex items-center gap-2.5 px-2 py-2 rounded-lg hover:bg-elevated transition-colors">

                {/* Avatar */}
                <div
                  className="relative w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 text-[11px] font-bold"
                  style={{
                    background: getRatingColor(friend.rating) + "33",
                    color: getRatingColor(friend.rating),
                  }}
                >
                  {friend.initials}
                  <span
                    className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-surface"
                    style={{ background: friend.online ? "#4ade80" : "#44445a" }}
                  />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <p className="text-[13px] font-semibold text-white truncate">{friend.handle}</p>
                  <p
                    className="text-[11px]"
                    style={{ color: friend.online ? "#4ade80" : "#44445a" }}
                  >
                    {friend.lastSeen}
                  </p>
                </div>

                {/* Rating */}
                <span
                  className="text-[12px] font-bold font-mono flex-shrink-0"
                  style={{ color: getRatingColor(friend.rating) }}
                >
                  {friend.rating}
                </span>

                {/* Challenge button */}
                {friend.online && (
                  <button className="text-[11px] font-bold text-accent px-2.5 py-1 bg-accent/10 border border-accent/30 rounded-md hover:bg-accent hover:text-white transition-colors flex-shrink-0">
                    Duel
                  </button>
                )}
              </div>
            ))}

            <button className="mt-2 w-full py-2.5 text-[12px] font-semibold text-white/25 border border-dashed border-border rounded-lg hover:text-accent hover:border-accent transition-colors">
              Find friends →
            </button>
          </>
        )}
      </div>
    </aside>
  );
}
