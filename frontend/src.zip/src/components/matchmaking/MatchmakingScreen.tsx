import { useState, useEffect } from "react";
import { getRatingColor, getRatingTitle } from "../../utils/rating";

interface MatchmakingScreenProps {
  onMatchFound: () => void;
}

interface ConfettiPiece {
  id: number;
  color: string;
  left: number;
  delay: number;
  duration: number;
  endX: number;
  rotation: number;
  isCircle: boolean;
}

const CONFETTI_COLORS = ["#7c6af7", "#4ade80", "#f7c06a", "#f87171", "#60a5fa", "#c084fc"];

export default function MatchmakingScreen({ onMatchFound }: MatchmakingScreenProps) {
  const [elapsed, setElapsed] = useState(0);
  const [found, setFound] = useState(false);
  const [confetti, setConfetti] = useState<ConfettiPiece[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setElapsed((prev) => {
        const next = prev + 1;

        // Minimum 5 seconds, then trigger match found
        if (next >= 6 && !found) {
          clearInterval(interval);
          setFound(true);
          spawnConfetti();
          setTimeout(onMatchFound, 1600);
        }

        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [found, onMatchFound]);

  function spawnConfetti() {
    const pieces: ConfettiPiece[] = Array.from({ length: 40 }, (_, i) => ({
      id: i,
      color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
      left: 5 + Math.random() * 90,
      delay: Math.random() * 0.5,
      duration: 1.8 + Math.random() * 1.5,
      endX: (Math.random() - 0.5) * 200,
      rotation: Math.random() * 720,
      isCircle: Math.random() > 0.45,
    }));
    setConfetti(pieces);
  }

  const formatElapsed = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  const playersScanned = Math.round(800 + elapsed * 120);

  return (
    <div className="relative flex-1 flex items-center justify-center overflow-hidden min-h-[calc(100vh-60px)]">

      {/* Grid background */}
      <div className="absolute inset-0 bg-grid opacity-35 pointer-events-none" />

      {/* Radial vignette */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse 60% 60% at 50% 50%, transparent 40%, #0a0a0f 100%)" }}
      />

      {/* Confetti */}
      {confetti.map((piece) => (
        <div
          key={piece.id}
          className="fixed top-[-12px] pointer-events-none z-30 animate-confetti"
          style={{
            left: `${piece.left}%`,
            width: piece.isCircle ? "9px" : "6px",
            height: piece.isCircle ? "9px" : "12px",
            background: piece.color,
            borderRadius: piece.isCircle ? "50%" : "2px",
            animationDuration: `${piece.duration}s`,
            animationDelay: `${piece.delay}s`,
            "--end-transform": `translateX(${piece.endX}px) translateY(110vh) rotate(${piece.rotation}deg)`,
          } as React.CSSProperties}
        />
      ))}

      {/* Main arena */}
      <div className="relative z-10 flex flex-col items-center w-full max-w-[680px] px-6">

        {/* Eyebrow label */}
        <p className="text-[11px] font-bold tracking-[3px] uppercase text-white/25 mb-9">
          Blitz Duel · Rated
        </p>

        {/* Fighter cards + VS */}
        <div className="flex items-stretch w-full">

          {/* You */}
          <div className="flex-1 flex flex-col gap-3.5 p-7 bg-card border border-accent/40 rounded-l-2xl relative overflow-hidden">
            <div className="absolute inset-0 pointer-events-none"
              style={{ background: "linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.02) 50%, transparent 60%)", backgroundSize: "200% 100%", animation: "shimmer 2.5s ease-in-out infinite" }}
            />

            {/* Avatar with spinning ring */}
            <div className="relative w-fit">
              <div className="w-[76px] h-[76px] rounded-full flex items-center justify-center text-[22px] font-extrabold text-white z-10 relative"
                style={{ background: "linear-gradient(135deg, #3b30a0, #7c6af7)" }}>
                TK
              </div>
              <div className="absolute inset-[-5px] rounded-full border border-accent/50 animate-spinSlow" />
              <div className="absolute inset-[-10px] rounded-full border border-accent/20 animate-spinSlow" style={{ animationDuration: "5s" }} />
            </div>

            <div>
              <p className="text-[16px] font-bold text-white">tourist_kid</p>
              <p className="text-[13px] font-mono" style={{ color: getRatingColor(1847) }}>1847</p>
            </div>

            <span
              className="text-[11px] font-bold px-2.5 py-1 rounded-full border w-fit"
              style={{ color: "#c084fc", borderColor: "rgba(192,132,252,0.3)", background: "rgba(192,132,252,0.08)" }}
            >
              {getRatingTitle(1847)}
            </span>
          </div>

          {/* VS divider */}
          <div className="flex flex-col items-center justify-center px-3 z-10 flex-shrink-0 gap-2.5">
            <div className="w-px h-8 bg-gradient-to-b from-transparent via-accent to-transparent animate-swordPulse" />
            <span className="text-[26px] font-extrabold font-mono text-accent tracking-[4px] animate-vsPulse">VS</span>
            <div className="w-px h-8 bg-gradient-to-b from-transparent via-accent to-transparent animate-swordPulse animation-delay-200" />
          </div>

          {/* Opponent */}
          <div className={`flex-1 flex flex-col gap-3.5 p-7 bg-card border rounded-r-2xl items-end relative overflow-hidden transition-colors duration-300 ${found ? "border-success/50" : "border-border"}`}>

            {!found ? (
              <>
                <div className="relative w-fit">
                  <div className="w-[76px] h-[76px] rounded-full border-2 border-dashed border-border-bright flex items-center justify-center bg-elevated">
                    <span className="text-[28px] text-white/20">?</span>
                  </div>
                  <div className="absolute inset-[-5px] rounded-full border border-border-bright/50 animate-spinReverse" />
                </div>
                <div className="text-right">
                  <p className="text-[16px] font-bold text-white/30">searching...</p>
                  <p className="text-[13px] font-mono text-white/20">????</p>
                </div>
                <span className="text-[11px] font-bold px-2.5 py-1 rounded-full border border-border text-white/25 w-fit">
                  ~±200
                </span>
              </>
            ) : (
              <div className="flex flex-col gap-3.5 items-end animate-fightIn">
                <div className="relative w-fit">
                  <div className="w-[76px] h-[76px] rounded-full flex items-center justify-center text-[22px] font-extrabold text-white"
                    style={{ background: "linear-gradient(135deg, #0f3d27, #1d9e75)" }}>
                    AB
                  </div>
                  <div className="absolute inset-[-5px] rounded-full border border-success/50 animate-spinReverse" />
                </div>
                <div className="text-right">
                  <p className="text-[16px] font-bold text-white">algo_beast</p>
                  <p className="text-[13px] font-mono" style={{ color: getRatingColor(1920) }}>1920</p>
                </div>
                <span className="text-[11px] font-bold px-2.5 py-1 rounded-full border border-success/30 w-fit"
                  style={{ color: "#4ade80", background: "rgba(74,222,128,0.08)" }}>
                  {getRatingTitle(1920)}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Progress / found state */}
        <div className="flex flex-col items-center gap-3.5 mt-9 w-full">
          {!found ? (
            <>
              {/* Progress bar */}
              <div className="w-[360px] h-[3px] bg-border rounded-full overflow-hidden relative">
                <div className="absolute inset-0 animate-barFill rounded-full"
                  style={{ background: "linear-gradient(90deg, #4f43b3, #7c6af7, #a78bfa)" }} />
              </div>

              <p className="text-[12px] font-semibold tracking-[1.5px] uppercase text-white/40 flex items-center gap-2">
                Scanning {playersScanned} players
                <span className="font-mono flex gap-px">
                  {[0, 1, 2].map((i) => (
                    <span
                      key={i}
                      className="inline-block animate-pulse2"
                      style={{ animationDelay: `${i * 0.2}s` }}
                    >
                      .
                    </span>
                  ))}
                </span>
              </p>

              <p className="text-[11px] font-mono text-white/20">{formatElapsed(elapsed)}</p>
            </>
          ) : (
            <div className="flex flex-col items-center gap-2.5 animate-popIn">
              <span className="text-[44px] leading-none">⚔️</span>
              <p className="text-[22px] font-extrabold text-accent tracking-tight">Match found!</p>
              <p className="text-[13px] text-white/30">Entering battle arena...</p>
            </div>
          )}
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2 justify-center mt-5">
          {["ELO band ±200", "Problem ~1800", "Rated · 30 min limit"].map((tag) => (
            <span key={tag} className="text-[10px] font-mono px-2.5 py-1 bg-elevated border border-border rounded-full text-white/25">
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
