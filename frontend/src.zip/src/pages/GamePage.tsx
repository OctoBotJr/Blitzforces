import { useState, useEffect, useRef } from "react";
import Navbar from "../components/layout/Navbar";
import MatchmakingScreen from "../components/matchmaking/MatchmakingScreen";
import PlayerHeader from "../components/game/PlayerHeader";
import ProblemBar from "../components/game/ProblemBar";
import SubmissionPanel from "../components/game/SubmissionPanel";
import ResultBanner from "../components/game/ResultBanner";
import { useTimer } from "../hooks/useTimer";
import type { Submission, Verdict, Problem } from "../types";

// ── Static data ──────────────────────────────────────────────────────────────

const PROBLEM: Problem = {
  id: "1923C",
  name: "Find the Median",
  contest: "Codeforces Round 921 (Div. 2)",
  rating: 1800,
  cfUrl: "https://codeforces.com/problemset/problem/1923/C",
};

// Simulated submission sequence: { delayMs, player, verdict, language, timeMs, memoryMb }
interface SimEvent {
  delayMs: number;
  player: "me" | "opp";
  verdict: Verdict;
  language: string;
  timeMs: string | null;
  memoryMb: string | null;
}

const SIM_SEQUENCE: SimEvent[] = [
  { delayMs: 3500,  player: "me",  verdict: "CE",  language: "C++17",   timeMs: null,       memoryMb: null     },
  { delayMs: 8000,  player: "opp", verdict: "WA",  language: "C++17",   timeMs: "234ms",    memoryMb: "14MB"   },
  { delayMs: 14000, player: "me",  verdict: "WA",  language: "C++17",   timeMs: "188ms",    memoryMb: "12MB"   },
  { delayMs: 20000, player: "opp", verdict: "TLE", language: "C++17",   timeMs: ">2000ms",  memoryMb: "21MB"   },
  { delayMs: 28000, player: "me",  verdict: "WA",  language: "C++17",   timeMs: "201ms",    memoryMb: "12MB"   },
  { delayMs: 35000, player: "opp", verdict: "RE",  language: "Python3", timeMs: null,       memoryMb: null     },
  { delayMs: 43000, player: "opp", verdict: "WA",  language: "C++17",   timeMs: "445ms",    memoryMb: "22MB"   },
  { delayMs: 52000, player: "me",  verdict: "AC",  language: "C++17",   timeMs: "156ms",    memoryMb: "11MB"   },
];

// ── Page component ────────────────────────────────────────────────────────────

type Screen = "matchmaking" | "game";

export default function GamePage() {
  const [screen, setScreen] = useState<Screen>("matchmaking");

  return screen === "matchmaking" ? (
    <div className="flex flex-col min-h-screen bg-base font-syne">
      <Navbar centerLabel="Finding match" />
      <MatchmakingScreen onMatchFound={() => setScreen("game")} />
    </div>
  ) : (
    <div className="flex flex-col min-h-screen bg-base font-syne">
      <Navbar centerLabel="Rated Battle" />
      <BattleArena />
    </div>
  );
}

// ── Battle arena ──────────────────────────────────────────────────────────────

function BattleArena() {
  const [mySubs, setMySubs]       = useState<Submission[]>([]);
  const [oppSubs, setOppSubs]     = useState<Submission[]>([]);
  const [winner, setWinner]       = useState<"me" | "opp" | null>(null);
  const [oppTyping, setOppTyping] = useState(false);
  const [gameOver, setGameOver]   = useState(false);

  const elapsed = useTimer(!gameOver);

  // Refs to keep timer callbacks stable (no stale closure over elapsed)
  const gameOverRef = useRef(gameOver);
  gameOverRef.current = gameOver;

  // Register all simulation timeouts once on mount
  useEffect(() => {
    const timers = SIM_SEQUENCE.map((event) =>
      setTimeout(() => {
        if (gameOverRef.current) return;

        const submission: Submission = {
          id:          crypto.randomUUID(),
          verdict:     event.verdict,
          language:    event.language,
          timeMs:      event.timeMs,
          memoryMb:    event.memoryMb,
          submittedAt: new Date(),
        };

        if (event.player === "me") {
          setMySubs((prev) => [submission, ...prev]);
          if (event.verdict === "AC") {
            setWinner("me");
            setGameOver(true);
          }
        } else {
          setOppSubs((prev) => [submission, ...prev]);
          if (event.verdict === "AC") {
            setWinner("opp");
            setGameOver(true);
          } else {
            // Show typing indicator ~2.5s before verdict appears
            setOppTyping(true);
            setTimeout(() => setOppTyping(false), 2800);
          }
        }
      }, event.delayMs)
    );

    return () => timers.forEach(clearTimeout);
  }, []);

  function handleRematch() {
    setMySubs([]);
    setOppSubs([]);
    setWinner(null);
    setGameOver(false);
  }

  // Estimated rating delta based on opponent rating difference
  const ratingDelta = Math.round(18 + (1920 - 1847) * 0.04);

  return (
    <div className="flex flex-col flex-1">

      {/* Player header with timer */}
      <PlayerHeader
        elapsed={elapsed}
        playerLeft={{
          handle:          "tourist_kid",
          rating:          1847,
          initials:        "TK",
          avatarGradient:  "linear-gradient(135deg, #3b30a0, #7c6af7)",
          submissionCount: mySubs.length,
          isMe:            true,
        }}
        playerRight={{
          handle:          "algo_beast",
          rating:          1920,
          initials:        "AB",
          avatarGradient:  "linear-gradient(135deg, #0f3d27, #1d9e75)",
          submissionCount: oppSubs.length,
        }}
      />

      {/* Problem strip */}
      <ProblemBar problem={PROBLEM} />

      {/* Dual submission panels */}
      <div className="flex flex-1 divide-x divide-border overflow-hidden">
        <div className="flex-1 flex flex-col">
          <SubmissionPanel
            handle="tourist_kid"
            submissions={mySubs}
            isMe
            dotColor="#7c6af7"
            side="left"
          />
        </div>
        <div className="flex-1 flex flex-col">
          <SubmissionPanel
            handle="algo_beast"
            submissions={oppSubs}
            isTyping={oppTyping}
            dotColor="#1d9e75"
            side="right"
          />
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between px-6 py-2.5 bg-surface border-t border-border">
        <div className="flex items-center gap-2 text-[12px] text-white/30">
          <span className="w-[7px] h-[7px] rounded-full bg-success animate-pulse2" />
          Live · polling every 5s
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[12px] font-mono text-white/30">
            Rated · ±{ratingDelta} pts
          </span>
          <button className="text-[12px] font-semibold text-danger px-3.5 py-1.5 border border-danger/20 bg-danger/5 rounded-md hover:bg-danger/10 transition-colors">
            Forfeit
          </button>
        </div>
      </div>

      {/* Result banner (shown when game ends) */}
      {winner && (
        <ResultBanner
          winner={winner}
          elapsedSeconds={elapsed}
          ratingDelta={ratingDelta}
          onRematch={handleRematch}
          onHome={() => window.location.reload()}
        />
      )}
    </div>
  );
}
