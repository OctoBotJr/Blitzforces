import Navbar from "../components/layout/Navbar";
import ProfileHero from "../components/profile/ProfileHero";
import RatingGraph from "../components/profile/RatingGraph";
import ActivityGrid from "../components/profile/ActivityGrid";
import StatCards from "../components/profile/StatCards";
import GameHistoryTable from "../components/profile/GameHistoryTable";
import { profileData, gameHistory } from "../data/profileData";
import { useEffect } from "react";
import { useLocation } from "react-router-dom";

export default function ProfilePage() {
  const location = useLocation();

  useEffect(() => {
    if (location.state?.scrollToBottom) {
      window.scrollTo({
        top: document.body.scrollHeight,
        behavior: "smooth",
      });
    }
  }, [location]);


  return (
    <div className="flex flex-col min-h-screen bg-base font-syne">
      <Navbar />

      <main className="flex-1 overflow-y-auto">
        <ProfileHero profile={profileData} />

        <div className="max-w-[1200px] mx-auto px-6 py-8 flex flex-col gap-6">
          <StatCards profile={profileData} />
          <RatingGraph history={profileData.ratingHistory} />
          <ActivityGrid days={profileData.activityGrid} />
          <GameHistoryTable entries={gameHistory} />
        </div>
      </main>
    </div>
  );
}
