import { useState, useMemo } from "react";
import Navbar from "../components/layout/Navbar";
import { rankingsData, type RankingEntry } from "../data/rankingsData";
import { getRatingColor, getRatingTitle } from "../utils/rating";

// ── Sparkline ─────────────────────────────────────────────────────────────────

function Sparkline({ data, color }: { data: number[]; color: string }) {
  if (data.length < 2) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const w = 64;
  const h = 24;
  const pad = 2;

  const points = data
    .map((v, i) => {
      const x = pad + (i / (data.length - 1)) * (w - pad * 2);
      const y = h - pad - ((v - min) / range) * (h - pad * 2);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  return (
    <svg
      width={w}
      height={h}
      viewBox={`0 0 ${w} ${h}`}
      className="overflow-visible"
    >
      <polyline
        points={points}
        fill="none"
        stroke={color}
        strokeWidth="1.5"
        strokeLinejoin="round"
        strokeLinecap="round"
        opacity="0.8"
      />
      {/* last dot */}
      {(() => {
        const last = data[data.length - 1];
        const lx = w - pad;
        const ly = h - pad - ((last - min) / range) * (h - pad * 2);
        return (
          <circle cx={lx.toFixed(1)} cy={ly.toFixed(1)} r="2.5" fill={color} />
        );
      })()}
    </svg>
  );
}

// ── Podium top-3 ──────────────────────────────────────────────────────────────

function PodiumCard({
  entry,
  size,
}: {
  entry: RankingEntry;
  size: "lg" | "md" | "sm";
}) {
  const color = getRatingColor(entry.rating);
  const heights = { lg: "h-36", md: "h-24", sm: "h-16" };
  const avatarSz = {
    lg: "w-16 h-16 text-xl",
    md: "w-14 h-14 text-lg",
    sm: "w-12 h-12 text-base",
  };
  const medals = ["🥇", "🥈", "🥉"];

  return (
    <div className="flex flex-col items-center gap-3">
      {/* Avatar */}
      <div className="relative">
        <div
          className={`${avatarSz[size]} rounded-full flex items-center justify-center font-extrabold text-white`}
          style={{
            background: `linear-gradient(135deg, ${color}55, ${color})`,
          }}
        >
          {entry.initials}
        </div>
        <div
          className="absolute inset-[-4px] rounded-full border opacity-40"
          style={{ borderColor: color }}
        />
        {entry.isOnline && (
          <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-success border-2 border-base" />
        )}
      </div>

      {/* Name */}
      <div className="text-center">
        <p className="text-[13px] font-bold text-white">{entry.handle}</p>
        <p className="text-[11px] font-mono mt-0.5" style={{ color }}>
          {entry.rating}
        </p>
      </div>

      {/* Podium block */}
      <div
        className={`w-24 ${heights[size]} flex items-start justify-center pt-2 rounded-t-xl border-t border-x`}
        style={{ background: color + "0d", borderColor: color + "33" }}
      >
        <span className="text-[22px]">{medals[entry.rank - 1]}</span>
      </div>
    </div>
  );
}

function Podium({ top3 }: { top3: RankingEntry[] }) {
  if (top3.length < 3) return null;
  return (
    <div className="flex items-end justify-center gap-4 py-8 px-6 bg-card border border-border rounded-2xl mb-6 relative overflow-hidden">
      {/* Grid bg */}
      <div className="absolute inset-0 bg-grid opacity-10 pointer-events-none" />
      <PodiumCard entry={top3[1]} size="md" />
      <PodiumCard entry={top3[0]} size="lg" />
      <PodiumCard entry={top3[2]} size="sm" />
    </div>
  );
}

// ── Table row ─────────────────────────────────────────────────────────────────

function TableRow({ entry, idx }: { entry: RankingEntry; idx: number }) {
  const color = getRatingColor(entry.rating);
  const winRate = Math.round((entry.gamesWon / (entry.gamesPlayed || 1)) * 100);
  const isTop3 = entry.rank <= 3;

  return (
    <div
      className={`grid items-center px-5 py-3 gap-x-4 border-b border-border/50 last:border-b-0 transition-colors hover:bg-elevated group ${
        entry.isMe
          ? "bg-accent/5 border-l-2 border-l-accent"
          : isTop3
            ? "bg-warn/[0.03]"
            : ""
      }`}
      style={{ gridTemplateColumns: "48px 40px 1fr 100px 72px 72px 80px 72px" }}
    >
      {/* Rank */}
      <div className="flex items-center justify-center">
        {isTop3 ? (
          <span className="text-[18px]">
            {["🥇", "🥈", "🥉"][entry.rank - 1]}
          </span>
        ) : (
          <span className="text-[13px] font-mono font-bold text-white/30">
            #{entry.rank}
          </span>
        )}
      </div>

      {/* Flag */}
      <span className="text-[16px] text-center">{entry.flag}</span>

      {/* Handle + name */}
      <div className="min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-[13px] font-bold text-white truncate">
            {entry.handle}
          </span>
          {entry.isMe && <span className="badge-you flex-shrink-0">you</span>}
          {entry.isOnline && (
            <span className="w-1.5 h-1.5 rounded-full bg-success flex-shrink-0" />
          )}
        </div>
        <span className="text-[11px] text-white/30 truncate block">
          {entry.displayName}
        </span>
      </div>

      {/* Rating */}
      <div className="flex flex-col gap-0.5">
        <span className="text-[14px] font-bold font-mono" style={{ color }}>
          {entry.rating}
        </span>
        <span className="text-[10px] text-white/25">
          {getRatingTitle(entry.rating)}
        </span>
      </div>

      {/* Weekly delta */}
      <span
        className="text-[13px] font-bold font-mono"
        style={{
          color:
            entry.weeklyDelta > 0
              ? "#4ade80"
              : entry.weeklyDelta < 0
                ? "#f87171"
                : "#888",
        }}
      >
        {entry.weeklyDelta > 0 ? "+" : ""}
        {entry.weeklyDelta}
      </span>

      {/* Win rate */}
      <div className="flex flex-col gap-1">
        <span className="text-[12px] font-mono text-white/60">{winRate}%</span>
        <div className="h-1 bg-border rounded-full overflow-hidden w-12">
          <div
            className="h-full rounded-full"
            style={{
              width: `${winRate}%`,
              background:
                winRate >= 60
                  ? "#4ade80"
                  : winRate >= 45
                    ? "#fbbf24"
                    : "#f87171",
            }}
          />
        </div>
      </div>

      {/* Games */}
      <span className="text-[12px] font-mono text-white/40">
        {entry.gamesWon}W·{entry.gamesPlayed - entry.gamesWon}L
      </span>

      {/* Sparkline */}
      <div className="flex justify-end">
        <Sparkline data={entry.ratingHistory} color={color} />
      </div>
    </div>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────

type TimeFilter = "alltime" | "weekly" | "monthly";
type RankFilter = "all" | "expert" | "master" | "candidate" | "specialist";

const TIME_LABELS: { key: TimeFilter; label: string }[] = [
  { key: "alltime", label: "All time" },
  { key: "monthly", label: "This month" },
  { key: "weekly", label: "This week" },
];

export default function RankingsPage() {
  const [search, setSearch] = useState("");
  const [timeFilter, setTimeFilter] = useState<TimeFilter>("alltime");
  const [rankFilter, setRankFilter] = useState<RankFilter>("all");

  const filtered = useMemo(() => {
    let list = [...rankingsData];

    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (e) =>
          e.handle.toLowerCase().includes(q) ||
          e.displayName.toLowerCase().includes(q),
      );
    }

    if (rankFilter !== "all") {
      const bands: Record<RankFilter, [number, number]> = {
        all: [0, 9999],
        expert: [1600, 1899],
        master: [2100, 2399],
        candidate: [1900, 2099],
        specialist: [1400, 1599],
      };
      const [lo, hi] = bands[rankFilter];
      list = list.filter((e) => e.rating >= lo && e.rating <= hi);
    }

    if (timeFilter === "weekly")
      list = list.sort((a, b) => b.weeklyDelta - a.weeklyDelta);
    if (timeFilter === "monthly")
      list = list.sort((a, b) => b.rating - a.rating);

    return list;
  }, [search, timeFilter, rankFilter]);

  const top3 = rankingsData.slice(0, 3);
  const myEntry = rankingsData.find((e) => e.isMe);
  const onlineCount = rankingsData.filter((e) => e.isOnline).length;

  return (
    <div className="flex flex-col min-h-screen bg-base font-syne">
      <Navbar />

      <main className="flex-1 overflow-y-auto">
        <div className="max-w-[1100px] mx-auto px-6 py-8">
          {/* Page header */}
          <div className="flex items-end justify-between mb-6">
            <div>
              <h1 className="text-[28px] font-extrabold tracking-tight text-white">
                Rankings
              </h1>
              <p className="text-[14px] text-white/40 mt-1 font-mono">
                {rankingsData.length} players · {onlineCount} online
              </p>
            </div>

            {/* Your rank card */}
            {myEntry && (
              <div className="flex items-center gap-3 px-4 py-3 bg-accent/10 border border-accent/30 rounded-xl">
                <div className="flex flex-col">
                  <span className="text-[11px] text-accent/70 font-bold uppercase tracking-wider">
                    Your rank
                  </span>
                  <span className="text-[24px] font-extrabold font-mono text-accent leading-none">
                    #{myEntry.rank}
                  </span>
                </div>
                <div className="w-px h-10 bg-accent/20" />
                <div className="flex flex-col">
                  <span className="text-[11px] text-white/30 uppercase tracking-wider">
                    Rating
                  </span>
                  <span
                    className="text-[20px] font-bold font-mono leading-none"
                    style={{ color: getRatingColor(myEntry.rating) }}
                  >
                    {myEntry.rating}
                  </span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[11px] text-white/30 uppercase tracking-wider">
                    Week
                  </span>
                  <span className="text-[16px] font-bold font-mono leading-none text-success">
                    +{myEntry.weeklyDelta}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Podium */}
          <Podium top3={top3} />

          {/* Controls */}
          <div className="flex items-center gap-3 mb-4 flex-wrap">
            {/* Search */}
            <div className="relative flex-1 min-w-[200px]">
              <svg
                className="absolute left-3 top-1/2 -translate-y-1/2 text-white/25"
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search player..."
                className="w-full pl-9 pr-4 py-2.5 bg-card border border-border rounded-xl text-[13px] text-white placeholder:text-white/25 focus:outline-none focus:border-accent transition-colors"
              />
            </div>

            {/* Time filter */}
            <div className="flex gap-1 bg-card border border-border rounded-xl p-1">
              {TIME_LABELS.map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => setTimeFilter(key)}
                  className={`px-3 py-1.5 text-[12px] font-semibold rounded-lg transition-colors ${
                    timeFilter === key
                      ? "bg-accent/15 text-accent"
                      : "text-white/40 hover:text-white/70"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Rank filter */}
            <select
              value={rankFilter}
              onChange={(e) => setRankFilter(e.target.value as RankFilter)}
              className="px-3.5 py-2.5 bg-card border border-border rounded-xl text-[13px] text-white/60 focus:outline-none focus:border-accent transition-colors cursor-pointer"
            >
              <option value="all">All ranks</option>
              <option value="master">Master (2100+)</option>
              <option value="candidate">Candidate Master</option>
              <option value="expert">Expert</option>
              <option value="specialist">Specialist</option>
            </select>
          </div>

          {/* Table */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {/* Column headers */}
            <div
              className="grid px-5 py-2.5 border-b border-border"
              style={{
                gridTemplateColumns: "48px 40px 1fr 100px 72px 72px 80px 72px",
              }}
            >
              {[
                "Rank",
                "",
                "Player",
                "Rating",
                "Δ Week",
                "Win%",
                "Record",
                "7-day",
              ].map((h) => (
                <span
                  key={h}
                  className="text-[11px] font-bold uppercase tracking-widest text-white/25"
                >
                  {h}
                </span>
              ))}
            </div>

            {filtered.length === 0 ? (
              <div className="py-16 text-center text-[13px] text-white/25">
                No players match this filter
              </div>
            ) : (
              filtered.map((entry, idx) => (
                <TableRow key={entry.handle} entry={entry} idx={idx} />
              ))
            )}
          </div>

          {/* Legend */}
          <div className="flex items-center gap-6 mt-4 flex-wrap">
            {[
              { label: "Grandmaster", color: "#ff3333", range: "2400+" },
              { label: "Master", color: "#c084fc", range: "2100–2399" },
              {
                label: "Candidate Master",
                color: "#c084fc",
                range: "1900–2099",
              },
              { label: "Expert", color: "#60a5fa", range: "1600–1899" },
              { label: "Specialist", color: "#4ade80", range: "1400–1599" },
            ].map(({ label, color, range }) => (
              <div key={label} className="flex items-center gap-1.5">
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ background: color }}
                />
                <span className="text-[11px] text-white/30">{label}</span>
                <span className="text-[10px] font-mono text-white/20">
                  {range}
                </span>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
